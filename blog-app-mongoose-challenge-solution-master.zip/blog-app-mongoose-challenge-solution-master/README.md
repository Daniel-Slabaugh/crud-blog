Blog app challenge solution
==========================
